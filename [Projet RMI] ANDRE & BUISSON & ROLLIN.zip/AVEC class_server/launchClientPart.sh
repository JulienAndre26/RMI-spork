cd ..

cd target/Client
chmod +x runClient.sh
./runClient.sh

# Blocking processus chutdown
read "a"