# Run server
java -Djava.security.policy="permissions.policy" -cp bin/ collection.MainServer
